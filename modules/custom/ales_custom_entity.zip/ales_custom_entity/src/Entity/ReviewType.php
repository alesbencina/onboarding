<?php

namespace Drupal\ales_custom_entity\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;

/**
 * Defines the review type entity.
 *
 * @ConfigEntityType(
 *   id = "review_type",
 *   label = @Translation("review type"),
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *   },
 *   config_prefix = "review_type",
 *   config_export = {
 *     "id",
 *     "label",
 *   },
 *   handlers = {
 *     "list_builder" = "Drupal\event\Controller\ReviewTypeListBuilder",
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\DefaultHtmlRouteProvider",
 *     },
 *   },
 *   links = {
 *     "collection" = "/admin/structure/review_type"
 *   },
 *   admin_permission = "administer review types",
 * )
 */
class ReviewType extends ConfigEntityBase {

  protected $id;

  protected $label;

}
